# Atlas — Multi-Platform Content Posting Agent

Post engaging content to **TikTok, Instagram, Twitter, Facebook, and YouTube** simultaneously with one command.

**Part of the OpenClaw Agent System** — Standalone agent focused on creative direction and content distribution.

## Quick Start (10 minutes)

### 1. Install Dependencies
```bash
npm install
# Installs: canvas, form-data, node-fetch
```

### 2. Configure
```bash
cp config/atlas-config.template.json config/atlas-config.json
# Edit config.json and add:
# - Postiz API key + integration IDs (for posting)
# - Image generation provider + API key (optional, for generating images)
```

### 3. Generate Images (Optional)
```bash
# Choose provider: openai (recommended), stability, replicate, or local
node scripts/generate-images.js \
  --config config.json \
  --prompts config/example-prompts.json \
  --output slides/
# Creates 6 AI-generated images
```

### 4. Add Text Overlays (Optional)
```bash
node scripts/add-text-overlay.js \
  --input slides/ \
  --texts config/example-captions.json \
  --output slides-final/
# Adds captions to your images
```

### 5. Post to All Platforms
```bash
node scripts/atlas-post.js \
  --config config.json \
  --caption "Your hook" \
  --images slides-final/slide1.png,slides-final/slide2.png \
  --platforms tiktok,instagram,twitter,facebook,youtube
```

Done! Your content is posted to all 5 platforms simultaneously.

## What You Get

✅ **Multi-platform posting** — One command, all platforms  
✅ **Content adaptation** — Each platform gets optimized format  
✅ **Rate limiting** — Smart API throttling (no overload)  
✅ **Error handling** — Graceful failures, detailed reporting  
✅ **Config-driven** — JSON configuration (no code changes)  
✅ **Modular design** — Each platform handler is independent  

## Platforms

| Platform | Format | Status | Notes |
|----------|--------|--------|-------|
| TikTok | 6-slide slideshow | Draft | User adds music, then publishes |
| Instagram | Single image + caption | Scheduled | Carousel coming Phase 2 |
| Twitter/X | Text + image | Scheduled | 280 char limit |
| Facebook | Single image + caption | Scheduled | Page followers see it |
| YouTube | Community tab post | Scheduled | Requires community feature enabled |

## Setup (Detailed)

### Get Postiz API Key
1. Go to [postiz.com](https://postiz.com)
2. Create account or sign in
3. Settings → API → Generate API Key
4. Save the key (you'll use it in config.json)

### Get Integration IDs
1. In Postiz: Connect each platform (TikTok, Instagram, Twitter, Facebook, YouTube)
2. For each platform: Integrations → Copy the integration ID
3. Save all 5 IDs in config.json

### Configure Atlas
```json
{
  "postiz": {
    "apiKey": "your-api-key-here",
    "integrationIds": {
      "tiktok": "id-from-postiz",
      "instagram": "id-from-postiz",
      "twitter": "id-from-postiz",
      "facebook": "id-from-postiz",
      "youtube": "id-from-postiz"
    }
  }
}
```

## Usage Examples

### Post to TikTok Only
```bash
node scripts/atlas-post.js \
  --config config.json \
  --caption "Check out my new feature!" \
  --images slide1.png,slide2.png,slide3.png \
  --platforms tiktok
```

### Post to All Platforms
```bash
node scripts/atlas-post.js \
  --config config.json \
  --caption "🚀 New release!" \
  --images app-screenshot.png \
  --platforms tiktok,instagram,twitter,facebook,youtube
```

### Add Title (for TikTok)
```bash
node scripts/atlas-post.js \
  --config config.json \
  --title "My Video Title" \
  --caption "Full caption here" \
  --images slide1.png,slide2.png
```

## Project Structure

```
atlas-agent/
├── scripts/
│   ├── atlas-post.js           # Main orchestrator (entry point)
│   └── postiz-adapter.js       # Platform posting logic
├── config/
│   └── atlas-config.template.json  # Config template
├── data/
│   ├── posts/                   # Saved posts
│   └── analytics/               # Analytics data
├── SKILL.md                     # Agent documentation
├── README.md                    # This file
├── package.json                 # Dependencies
├── .env.template               # Environment setup
└── .gitignore                  # Git config
```

## Cost

**Monthly Baseline:**
- Postiz: $50-99/mo (covers all 5 platforms)

**Image Generation (Pay-as-You-Go):**
- OpenAI (DALL-E 3): $0.04-0.08 per image — RECOMMENDED
- Stability AI: $0.02-0.03 per image
- Replicate (Flux): $0.03-0.07 per image
- Local: Free (you provide images)

**Example Monthly Usage:**
- 30 posts/month × 6 images/post × $0.06/image = ~$10.80 for image generation
- Postiz: ~$75/mo
- **Total: ~$86/mo for full automation**

**Phase 2 (Optional):**
- ElevenLabs voiceover: $10-99/mo
- Video generation: $540+/mo

## Troubleshooting

### "Postiz API key required"
- Check your config.json has `postiz.apiKey`
- Verify key is correct in Postiz dashboard

### "Integration ID not configured"
- Each platform needs an integration ID
- Check Postiz dashboard: Integrations section
- Copy all 5 IDs into config.json

### "Image not found"
- Verify image paths are correct
- Files must exist before running
- Use absolute paths or relative to working directory

### "TikTok post stuck in draft"
- This is normal! TikTok API doesn't allow automated music
- Log into TikTok > Drafts
- Add music > Publish

## Phase 2 Roadmap

- 🤖 AI image generation (auto-create slides)
- 🎬 Video support (YouTube/TikTok Shorts)
- 📊 Analytics aggregation (unified dashboard)
- 🎨 Template system (predefined designs)
- ⏰ Smart scheduling (optimal times per platform)
- 🔄 Auto-adaptation (content resized per platform)

## Security

- ✅ No hardcoded credentials
- ✅ .env file support
- ✅ Config template for safe setup
- ✅ API keys in environment variables only

**DO NOT** commit config.json with real credentials. Use .env files.

## License

MIT

## Questions?

See SKILL.md for detailed documentation.

---

**Built with ❤️ as part of the OpenClaw Agent System**

Standalone agent. Deploy independently. Scale with your needs.
