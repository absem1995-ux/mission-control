# Atlas Unified Deployment Guide

Deploy the complete Atlas system as one integrated package.

---

## What You're Deploying

**Atlas v1.1** — Complete content automation system

```
Input (Trends) 
    ↓
Create (Images + Text)
    ↓
Distribute (5 Platforms)
    ↓
Learn (Analytics + Optimization)
    ↓
Improve (Apply Learnings)
    ↓
Repeat
```

---

## Pre-Deployment Checklist

### Get API Keys
- [ ] OpenAI API key: https://platform.openai.com/account/api-keys
- [ ] Postiz API key: https://postiz.com (Settings → API)
- [ ] Postiz integration IDs (TikTok, Instagram, Twitter, Facebook, YouTube)

### Prepare Environment
- [ ] Node.js 18+ installed
- [ ] 50MB+ disk space
- [ ] Internet connection
- [ ] 10 minutes setup time

### Test Data
- [ ] One test image (for validation)
- [ ] Test hooks/captions (or use examples)
- [ ] Test Postiz credentials

---

## 3-Minute Deployment

### Step 1: Extract (30 seconds)
```bash
tar -xzf atlas-agent.tar.gz
cd atlas-agent
```

### Step 2: Install (1 minute)
```bash
npm install
```

### Step 3: Configure (1 minute)
```bash
cp config/atlas-config.template.json config/atlas-config.json

# Edit config.json with your API keys:
# - imageGen.apiKey (OpenAI)
# - postiz.apiKey
# - postiz.integrationIds (all 5 platforms)
```

### Step 4: Test (1 minute)
```bash
# Test with one platform first
node scripts/atlas-post.js \
  --config config.json \
  --caption "Atlas test post" \
  --images test-image.png \
  --platforms instagram
```

Expected output:
```
ℹ️  ✅ Config validated
📤 STEP 1: Uploading images...
✅ test-image.png (uploaded)
📱 STEP 2: Posting to platforms...
📸 Creating Instagram post...
✅ Instagram post scheduled
```

**If successful:** System is ready. Proceed to automation.

---

## Single-Command Full Deployment

### Production Setup
```bash
# 1. Extract and install
tar -xzf atlas-agent.tar.gz && cd atlas-agent && npm install

# 2. Configure
cp config/atlas-config.template.json config/atlas-config.json
# Edit with your API keys

# 3. First full run (generate + post + wait for analytics)
npm run workflow

# 4. Next day: Run self-optimizer
node scripts/self-optimizer.js --config config.json

# 5. Schedule for automation (see below)
```

---

## Automated Scheduling

### Option A: Local Cron Job (Linux/Mac)

**Create script: `atlas-daily.sh`**
```bash
#!/bin/bash
cd /path/to/atlas-agent
node scripts/trend-research.js --config config.json --all-platforms
node scripts/generate-images.js --config config.json --prompts config/example-prompts.json --output slides/raw
node scripts/add-text-overlay.js --input slides/raw --texts config/example-captions.json --output slides/final
node scripts/atlas-post.js --config config.json --caption "Daily post" --images slides/final/slide*.png --platforms tiktok,instagram,twitter,facebook,youtube
```

**Make executable:**
```bash
chmod +x atlas-daily.sh
```

**Add to crontab (runs daily at 8am):**
```bash
crontab -e
# Add line:
0 8 * * * /path/to/atlas-daily.sh
```

**Collect analytics and optimize (runs daily at 8pm):**
```bash
crontab -e
# Add line:
0 20 * * * cd /path/to/atlas-agent && node scripts/collect-analytics.js --config config.json && node scripts/self-optimizer.js --config config.json
```

---

### Option B: GitHub Actions (Recommended)

**Create `.github/workflows/atlas-daily.yml`:**
```yaml
name: Atlas Daily Automation

on:
  schedule:
    - cron: "0 8 * * *"  # 8am UTC daily

jobs:
  generate-and-post:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Install dependencies
        run: npm install
      
      - name: Research trends
        run: node scripts/trend-research.js --config config.json --all-platforms
        env:
          OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
      
      - name: Generate images
        run: node scripts/generate-images.js --config config.json --prompts config/example-prompts.json --output slides/raw
        env:
          OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
      
      - name: Add text overlays
        run: node scripts/add-text-overlay.js --input slides/raw --texts config/example-captions.json --output slides/final
      
      - name: Post to platforms
        run: node scripts/atlas-post.js --config config.json --caption "Daily update" --images slides/final/slide*.png --platforms tiktok,instagram,twitter,facebook,youtube
        env:
          POSTIZ_API_KEY: ${{ secrets.POSTIZ_API_KEY }}

  collect-and-optimize:
    runs-on: ubuntu-latest
    needs: generate-and-post
    
    steps:
      - uses: actions/checkout@v3
      
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Install dependencies
        run: npm install
      
      - name: Collect analytics (after 24h)
        run: node scripts/collect-analytics.js --config config.json --days 1
        env:
          POSTIZ_API_KEY: ${{ secrets.POSTIZ_API_KEY }}
      
      - name: Self-optimize
        run: node scripts/self-optimizer.js --config config.json
```

**Add secrets to GitHub (Settings → Secrets):**
- `OPENAI_API_KEY`
- `POSTIZ_API_KEY`

---

### Option C: OpenClaw Integration

**Copy to OpenClaw skills:**
```bash
cp -r atlas-agent /home/openclaw/.openclaw/workspace/skills/atlas
```

**Add to OpenClaw config (openclaw-config.json):**
```json
{
  "skills": {
    "atlas": {
      "enabled": true,
      "path": "/home/openclaw/.openclaw/workspace/skills/atlas",
      "schedule": {
        "generate": "0 8 * * *",
        "analyze": "0 20 * * *"
      }
    }
  }
}
```

**Restart OpenClaw:**
```bash
openclaw gateway restart
```

---

### Option D: Docker (Container Deployment)

**Create `Dockerfile` in atlas-agent:**
```dockerfile
FROM node:18-slim

WORKDIR /app

# Copy atlas agent
COPY . .

# Install dependencies
RUN npm install

# Create data directories
RUN mkdir -p data/posts data/analytics data/trends data/lessons

# Environment variables
ENV NODE_ENV=production

# Run atlas workflow
CMD ["npm", "run", "workflow"]
```

**Build image:**
```bash
docker build -t atlas-agent:latest .
```

**Run container (one-time):**
```bash
docker run -e OPENAI_API_KEY="sk-..." \
           -e POSTIZ_API_KEY="..." \
           -v atlas-data:/app/data \
           atlas-agent:latest
```

**Run with scheduler (Kubernetes):**
```yaml
apiVersion: batch/v1
kind: CronJob
metadata:
  name: atlas-daily
spec:
  schedule: "0 8 * * *"
  jobTemplate:
    spec:
      template:
        spec:
          containers:
          - name: atlas
            image: atlas-agent:latest
            env:
            - name: OPENAI_API_KEY
              valueFrom:
                secretKeyRef:
                  name: atlas-secrets
                  key: openai_key
            - name: POSTIZ_API_KEY
              valueFrom:
                secretKeyRef:
                  name: atlas-secrets
                  key: postiz_key
            volumeMounts:
            - name: data
              mountPath: /app/data
          volumes:
          - name: data
            persistentVolumeClaim:
              claimName: atlas-data
          restartPolicy: OnFailure
```

---

## Config File (Single Source of Truth)

**`config/atlas-config.json`** controls everything:

```json
{
  "app": {
    "name": "Your App Name",
    "description": "What your app does"
  },
  
  "imageGen": {
    "provider": "openai",
    "model": "gpt-image-1.5",
    "apiKey": "sk-proj-..."
  },
  
  "postiz": {
    "apiKey": "your-postiz-key",
    "integrationIds": {
      "tiktok": "tiktok-integration-id",
      "instagram": "instagram-integration-id",
      "twitter": "twitter-integration-id",
      "facebook": "facebook-integration-id",
      "youtube": "youtube-integration-id"
    }
  },
  
  "posting": {
    "schedule": {
      "tiktok": ["7:00", "16:00", "21:00"],
      "instagram": ["8:00", "17:00", "20:00"],
      "twitter": ["9:00", "12:00", "18:00"],
      "facebook": ["10:00", "15:00", "19:00"],
      "youtube": ["11:00", "14:00", "22:00"]
    }
  },
  
  "optimizations": {
    "hookStrategy": "80% curiosity, 20% problem-solving",
    "alwaysAddText": true,
    "platformPriority": {
      "tiktok": 0.40,
      "instagram": 0.30,
      "twitter": 0.15,
      "youtube": 0.10,
      "facebook": 0.05
    }
  }
}
```

**One config. Entire system configured.**

---

## Monitoring & Maintenance

### Daily Checks
```bash
# After posting (check success)
tail -f data/posts/post-*.json

# After analytics collection
tail -f data/analytics/analytics-*.json

# After optimization
tail -f data/lessons/lessons-*.json
```

### Weekly Checks
```bash
# Review trends
cat data/trends/trends-$(date +%Y-%m-%d).json

# Check performance trends
grep "engagement" data/analytics/*.json | sort

# Verify recommendations
node scripts/self-optimizer.js --config config.json
```

### Monthly Review
```bash
# Total posts
ls data/posts/*.json | wc -l

# Total views (estimate)
jq '.platforms[] | .totalViews' data/analytics/*.json | paste -sd+ | bc

# Average engagement
jq '.platforms[] | .avgEngagement' data/analytics/*.json | awk '{sum+=$1; count++} END {print sum/count}'

# Recommendations applied
grep "ACTIVE" data/lessons/*.json | wc -l
```

---

## Rollback/Recovery

### If posting fails:
```bash
# Repost the same content
node scripts/atlas-post.js \
  --config config.json \
  --caption "Your caption" \
  --images data/posts/last-post-images/* \
  --platforms instagram,twitter  # Try different platforms
```

### If config corrupts:
```bash
# Restore from template
cp config/atlas-config.template.json config/atlas-config.json
# Re-enter API keys
```

### If data directory fills up:
```bash
# Archive old data
tar -czf data-backup-$(date +%Y-%m-%d).tar.gz data/
rm -rf data/*
mkdir -p data/{posts,analytics,trends,lessons}
```

---

## Troubleshooting

### "API key rejected"
```bash
# Check key is correct
echo $OPENAI_API_KEY

# Verify at OpenAI dashboard:
# https://platform.openai.com/account/api-keys
```

### "Image generation timeout"
```bash
# Increase timeout (edit generate-images.js)
const timeoutMs = 180000;  // 3 minutes instead of 2

# Retry generation
node scripts/generate-images.js --config config.json --prompts prompts.json --output slides/
```

### "Posts not appearing live"
```bash
# Check Postiz dashboard:
# https://dashboard.postiz.com/posts

# TikTok posts are in DRAFT (need manual music)
# Others should appear in 5-15 minutes
```

### "No analytics collected"
```bash
# Wait 24-48 hours (API delay)
# Then retry:
node scripts/collect-analytics.js --config config.json --days 7
```

---

## Performance Optimization

### To speed up generation:
```bash
# Use Stability AI (faster, cheaper)
{
  "imageGen": {
    "provider": "stability",
    "model": "stable-diffusion-xl-1024-v1-0"
  }
}
```

### To reduce costs:
```bash
# Use Replicate (flexible pricing)
{
  "imageGen": {
    "provider": "replicate",
    "model": "black-forest-labs/flux-1.1-pro"
  }
}

# Or local images (free)
{
  "imageGen": {
    "provider": "local"
  }
}
```

### To batch process:
```bash
# Generate 10 post batches
for i in {1..10}; do
  node scripts/generate-images.js --config config.json --prompts prompts.json --output slides-$i/
  node scripts/add-text-overlay.js --input slides-$i/ --texts captions.json --output slides-$i-final/
done

# Schedule posting throughout week
for i in {1..10}; do
  node scripts/atlas-post.js --config config.json --images slides-$i-final/slide*.png
  sleep 86400  # Wait 24 hours before next batch
done
```

---

## Complete Deployment Timeline

| Time | Action |
|------|--------|
| T+0 min | Extract, install, configure |
| T+5 min | Test with one platform |
| T+10 min | First full run (generate + post) |
| T+20 min | Schedule automation (cron/GitHub Actions) |
| T+24h | Collect analytics |
| T+24h | Run self-optimizer |
| T+48h | Check performance improvements |
| T+72h | System fully operational |

---

## Success Metrics (First Week)

Track these:
- [ ] Posts created: 7+
- [ ] Posts posted: 7/7 (100%)
- [ ] Analytics collected: 5+ data points
- [ ] Self-optimizer reports: 2+
- [ ] Recommendations applied: Yes
- [ ] Views/post: >1,000
- [ ] Engagement rate: >5%

---

## Summary

**Atlas deployed as:**
- ✅ Single package (atlas-agent.tar.gz)
- ✅ Single config file (atlas-config.json)
- ✅ Single npm command (npm run workflow)
- ✅ 4 deployment options (local, cron, GitHub Actions, Docker)
- ✅ Automated (hands-off after setup)
- ✅ Monitored (JSON output files)
- ✅ Recoverable (backups, rollback procedures)

**Deployment:** 3 minutes  
**First post:** 10 minutes  
**Full automation:** 30 minutes  
**First results:** 24-48 hours  

---

_Deploy once. Run forever. Watch it improve every day._
