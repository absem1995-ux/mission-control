# Atlas Complete Workflow

## Full End-to-End Example

Here's how to use Atlas from start to finish.

---

## Step 1: Setup (One-Time)

```bash
# Extract and navigate
tar -xzf atlas-agent.tar.gz
cd atlas-agent

# Install dependencies
npm install

# Copy config template
cp config/atlas-config.template.json config/atlas-config.json

# Copy env template
cp .env.template .env
```

### Edit `config/atlas-config.json`

Get your API keys:
- **Postiz API key:** https://postiz.com → Settings → API
- **Image generation provider:** OpenAI, Stability, or Replicate (choose one)

```json
{
  "app": {
    "name": "My App",
    "description": "What your app does"
  },
  "postiz": {
    "apiKey": "your-postiz-api-key",
    "integrationIds": {
      "tiktok": "postiz-tiktok-integration-id",
      "instagram": "postiz-instagram-integration-id",
      "twitter": "postiz-twitter-integration-id",
      "facebook": "postiz-facebook-integration-id",
      "youtube": "postiz-youtube-integration-id"
    }
  },
  "imageGen": {
    "provider": "openai",
    "model": "gpt-image-1.5",
    "apiKey": "sk-your-openai-api-key"
  }
}
```

### Edit `.env`

```bash
POSTIZ_API_KEY=your_postiz_key
OPENAI_API_KEY=sk-your-openai-key
DEFAULT_PLATFORMS=tiktok,instagram,twitter,facebook,youtube
```

---

## Step 2: Create Prompts File

Create `prompts.json` (defines what images to generate):

```bash
cat > prompts.json << 'EOF'
{
  "base": "A beautiful mobile app dashboard showing a modern user interface, professional design, vibrant colors, clean layout, high quality product photography",
  "slides": [
    "Colorful metrics dashboard with charts and statistics, minimalist design, clean typography",
    "User profile page with profile picture and bio, modern gradient background, rounded buttons",
    "Settings panel with toggle switches and options, light theme, professional layout",
    "Notifications center showing alerts and messages, clean design, readable typography",
    "Data visualization showing interactive charts and graphs, modern dashboard style",
    "Call to action screen with prominent download button, inspiring design, high contrast"
  ]
}
EOF
```

---

## Step 3: Create Captions File

Create `captions.json` (text to overlay on images):

```bash
cat > captions.json << 'EOF'
[
  "Wait, you can\ndo that?\n✨",
  "Finally, an app\nthat actually gets it 🎯",
  "Your workflow\njust got easier",
  "Never miss\na single thing 🔔",
  "See what matters\nin seconds 📊",
  "Try it free\nno credit card needed"
]
EOF
```

---

## Step 4: Generate Images

```bash
node scripts/generate-images.js \
  --config config/atlas-config.json \
  --prompts prompts.json \
  --output slides/raw
```

**Output:**
```
🎨 Generating 6 images using openai/gpt-image-1.5
   Provider: openai
   Model: gpt-image-1.5
   Output: slides/raw

  🔄 Slide 1...
  ✅ Slide 1 generated
  🔄 Slide 2...
  ✅ Slide 2 generated
  ... (continue for all 6)

📊 Results: 6/6 generated

✨ Done! Images ready for posting.
```

---

## Step 5: Add Text Overlays

```bash
node scripts/add-text-overlay.js \
  --input slides/raw \
  --texts captions.json \
  --output slides/final
```

**Output:**
```
✍️  Adding text overlays to 6 images

  ✅ Slide 1 — "Wait, you can\ndo that?"
  ✅ Slide 2 — "Finally, an app\nthat actually..."
  ... (continue for all 6)

📸 Slides with text overlays saved to slides/final

✨ Done!
```

---

## Step 6: Post to All Platforms

```bash
node scripts/atlas-post.js \
  --config config/atlas-config.json \
  --caption "🚀 Just launched! Check out what we built. Try it free, no credit card needed." \
  --images slides/final/slide1.png,slides/final/slide2.png,slides/final/slide3.png,slides/final/slide4.png,slides/final/slide5.png,slides/final/slide6.png \
  --platforms tiktok,instagram,twitter,facebook,youtube
```

**Output:**
```
ℹ️  ✅ Config validated

📤 STEP 1: Uploading images...
📤 Uploading image 1/6: slide1.png
✅ slide1.png (uploaded to Postiz)
📤 Uploading image 2/6: slide2.png
✅ slide2.png (uploaded to Postiz)
... (continue for all 6)

📱 STEP 2: Posting to platforms...

🎵 Creating TikTok post...
✅ TikTok post created (draft - user adds music)

📸 Creating Instagram post...
✅ Instagram post scheduled

🐦 Creating Twitter/X post...
✅ Twitter/X post scheduled

👤 Creating Facebook post...
✅ Facebook post scheduled

🎥 Creating YouTube post...
✅ YouTube community post scheduled

📊 STEP 3: Results
============================================================
📋 POSTING SUMMARY
============================================================
✅ Successful: 5/5
   • TIKTOK - draft
   • INSTAGRAM - scheduled
   • TWITTER - scheduled
   • FACEBOOK - scheduled
   • YOUTUBE - scheduled
============================================================
```

---

## Step 7: Monitor Analytics (Next Day)

After posts go live (typically within 24 hours), collect analytics:

```bash
node scripts/collect-analytics.js \
  --config config/atlas-config.json \
  --days 1
```

**Output:**
```
📊 Fetching posts from last 1 days (2025-02-19 - 2025-02-20)
✅ Fetched 5 posts

============================================================
📈 ANALYTICS REPORT
============================================================

TIKTOK
  Posts: 1
  Total views: 3,250
  Total likes: 425
  Total comments: 120
  Avg views/post: 3,250
  Engagement rate: 16.92%

INSTAGRAM
  Posts: 1
  Total views: 1,840
  Total likes: 156
  Total comments: 32
  Avg views/post: 1,840
  Engagement rate: 10.22%

TWITTER
  Posts: 1
  Total views: 892
  Total likes: 67
  Total comments: 18
  Avg views/post: 892
  Engagement rate: 9.53%

FACEBOOK
  Posts: 1
  Total views: 450
  Total likes: 42
  Total comments: 8
  Avg views/post: 450
  Engagement rate: 11.11%

YOUTUBE
  Posts: 1
  Total views: 1,205
  Total likes: 89
  Total comments: 24
  Avg views/post: 1,205
  Engagement rate: 9.38%

============================================================
TOTAL
  Posts: 5
  Total views: 7,637
  Avg views/post: 1,527
============================================================

💾 Analytics saved to: data/analytics/analytics-2025-02-20.json
```

---

## Repeated Workflow (Weekly)

Once setup is done, running Atlas weekly is simple:

```bash
# Week 2: Generate new images
node scripts/generate-images.js --config config.json --prompts prompts.json --output slides/raw

# Add text overlays
node scripts/add-text-overlay.js --input slides/raw --texts captions.json --output slides/final

# Post to all platforms
node scripts/atlas-post.js --config config.json --caption "New week, new content! 🚀" --images slides/final/slide*.png --platforms tiktok,instagram,twitter,facebook,youtube

# Check analytics next day
node scripts/collect-analytics.js --config config.json --days 1
```

**Time per cycle:** ~5 minutes (after images generate, ~3-5 min depending on provider)

---

## Automation (Scheduled Posts)

### Option 1: Cron Job (Linux/Mac)

```bash
# Create script: weekly-post.sh
#!/bin/bash
cd /path/to/atlas-agent
node scripts/generate-images.js --config config.json --prompts prompts.json --output slides/raw
node scripts/add-text-overlay.js --input slides/raw --texts captions.json --output slides/final
node scripts/atlas-post.js --config config.json --caption "Weekly update! ✨" --images slides/final/slide*.png --platforms tiktok,instagram,twitter,facebook,youtube

# Add to crontab (runs every Monday at 8am)
crontab -e
# Add line: 0 8 * * 1 /path/to/weekly-post.sh
```

### Option 2: GitHub Actions

Create `.github/workflows/weekly-post.yml`:

```yaml
name: Weekly Post
on:
  schedule:
    - cron: "0 8 * * 1"  # Monday 8am UTC

jobs:
  post:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: npm install
      - run: |
          node scripts/generate-images.js --config config.json --prompts prompts.json --output slides/raw
          node scripts/add-text-overlay.js --input slides/raw --texts captions.json --output slides/final
          node scripts/atlas-post.js --config config.json --caption "Weekly update! ✨" --images slides/final/slide*.png --platforms tiktok,instagram,twitter,facebook,youtube
          node scripts/collect-analytics.js --config config.json --days 7
        env:
          OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
          POSTIZ_API_KEY: ${{ secrets.POSTIZ_API_KEY }}
```

### Option 3: OpenClaw Cron (Built-In)

```bash
# Schedule with OpenClaw
cron add \
  --schedule "0 8 * * 1" \
  --payload '{"kind": "systemEvent", "text": "Generate and post content for this week"}' \
  --name "Atlas Weekly Post"
```

---

## Cost Breakdown (This Example)

- **Postiz:** $75/mo (all 5 platforms)
- **OpenAI DALL-E 3:** 6 images × $0.06 = $0.36 per post
- **Weekly (4 posts/mo):** 4 × $0.36 = ~$1.44/mo
- **Monthly Total:** ~$76.44/mo

---

## Troubleshooting

### Image Generation Fails
```bash
# Retry (completed images are skipped)
node scripts/generate-images.js --config config.json --prompts prompts.json --output slides/raw

# Check API key
echo $OPENAI_API_KEY  # Should show your key
```

### Posts Not Showing Live
- **TikTok:** Draft mode — you must add music manually and publish
- **Others:** Check Postiz dashboard to see if scheduled
- **Wait:** Can take 5-15 minutes for posts to go live

### Analytics Shows Zero Views
- Posts need 24 hours to accumulate views
- Check back tomorrow
- Verify posts actually published (check platforms manually)

---

## Next Steps

1. ✅ Setup (config.json, API keys)
2. ✅ First post (follow steps 4-7)
3. ✅ Automate (set up cron/GitHub Actions)
4. ✅ Optimize (analyze performance, improve captions)
5. ✅ Scale (create variations, test different platforms)

---

_Ready to run. Execute this workflow weekly for 30+ automated posts/month._
