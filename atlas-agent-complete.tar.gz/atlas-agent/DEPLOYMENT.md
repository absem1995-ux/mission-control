# Atlas Deployment Guide

Atlas is a **standalone agent** — deploy independently from other agents. Deploy now, or combine with other agents later.

## Deployment Options

### Option 1: Local Development (Fastest)
```bash
# Clone/extract atlas-agent
cd atlas-agent

# Install dependencies
npm install

# Setup config
cp config/atlas-config.template.json config/atlas-config.json
# Edit config.json with your Postiz API key + integration IDs

# Test
node scripts/atlas-post.js --caption "Test" --images test.png

# Deploy to production
# Set production environment variables (see .env.template)
export POSTIZ_API_KEY="your-key"
export POSTIZ_TIKTOK_ID="your-id"
# ... other integrations
```

### Option 2: Docker Deployment
```dockerfile
# Dockerfile
FROM node:18-slim

WORKDIR /app
COPY atlas-agent .

RUN npm install --production

# Environment variables from config
ENV POSTIZ_API_KEY=""
ENV POSTIZ_TIKTOK_ID=""
ENV POSTIZ_INSTAGRAM_ID=""
ENV POSTIZ_TWITTER_ID=""
ENV POSTIZ_FACEBOOK_ID=""
ENV POSTIZ_YOUTUBE_ID=""

ENTRYPOINT ["node", "scripts/atlas-post.js"]
```

Build and run:
```bash
docker build -t atlas-agent .
docker run -e POSTIZ_API_KEY="..." atlas-agent --caption "Test" --images test.png
```

### Option 3: OpenClaw Integration
Deploy as an OpenClaw skill (advanced):

```bash
# Copy to OpenClaw skills directory
cp -r atlas-agent /home/openclaw/.openclaw/workspace/skills/atlas

# Add to OpenClaw config (openclaw-config.json)
{
  "skills": {
    "atlas": {
      "enabled": true,
      "path": "/home/openclaw/.openclaw/workspace/skills/atlas"
    }
  }
}

# Restart OpenClaw
openclaw gateway restart
```

### Option 4: GitHub + Actions
```bash
# Push to GitHub
git init
git add .
git commit -m "Atlas Agent v1.0"
git remote add origin https://github.com/yourname/atlas-agent.git
git push -u origin main

# GitHub Actions for scheduling posts (example)
# .github/workflows/daily-post.yml
name: Daily Post
on:
  schedule:
    - cron: "0 8 * * *"  # 8am daily

jobs:
  post:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2
      - run: npm install
      - run: |
          node scripts/atlas-post.js \
            --caption "Daily update!" \
            --images slide1.png \
            --platforms tiktok,instagram,twitter
        env:
          POSTIZ_API_KEY: ${{ secrets.POSTIZ_API_KEY }}
```

## Step-by-Step Setup (15 minutes)

### Step 1: Extract Atlas
```bash
tar -xzf atlas-agent.tar.gz
cd atlas-agent
```

### Step 2: Install Dependencies
```bash
npm install
# Output: added 2 packages (form-data, node-fetch)
```

### Step 3: Get Postiz API Key
1. Go to https://postiz.com
2. Sign up or log in
3. Settings → API → Generate API Key
4. Copy the key

### Step 4: Configure Platforms
In Postiz:
1. Connect TikTok account
2. Connect Instagram account
3. Connect Twitter account
4. Connect Facebook account
5. Connect YouTube account
6. For each: copy the Integration ID

### Step 5: Create Config
```bash
cp config/atlas-config.template.json config/atlas-config.json
```

Edit `config/atlas-config.json`:
```json
{
  "postiz": {
    "apiKey": "your-postiz-api-key-here",
    "integrationIds": {
      "tiktok": "id-from-postiz-dashboard",
      "instagram": "id-from-postiz-dashboard",
      "twitter": "id-from-postiz-dashboard",
      "facebook": "id-from-postiz-dashboard",
      "youtube": "id-from-postiz-dashboard"
    }
  }
}
```

### Step 6: Test
Create a test image or use an existing one:
```bash
node scripts/atlas-post.js \
  --config config/atlas-config.json \
  --caption "Testing Atlas agent" \
  --images test-image.png \
  --platforms tiktok,instagram
```

Expected output:
```
ℹ️  ✅ Config validated
📤 STEP 1: Uploading images...
📤 Uploading image 1/1: test-image.png
✅ test-image.png (uploaded to Postiz)
📱 STEP 2: Posting to platforms...
🎵 Creating TikTok post...
✅ TikTok post created (draft - user adds music)
📸 Creating Instagram post...
✅ Instagram post scheduled
📊 STEP 3: Results
==================================================
📋 POSTING SUMMARY
==================================================
✅ Successful: 2/2
   • TIKTOK - draft
   • INSTAGRAM - scheduled
```

### Step 7: Production Ready
Move to production:
```bash
# Option A: Use environment variables
export POSTIZ_API_KEY="your-key"
export POSTIZ_TIKTOK_ID="id"
# ... etc

# Option B: Use .env file
cp .env.template .env
# Edit .env with your credentials
# .env is git-ignored (safe)

# Option C: Docker (recommended)
# Use docker deployment option above
```

## Integrating with Other Agents

### Later: Combine with Morgan (COO)
When deploying full agent system:
```
morgan/ (COO) ← orchestrates all agents
├── atlas/ (Creative Director)
├── astra/ (Operations)
├── sentinel/ (Support)
└── quinn/ (Communications)
```

For now: **Atlas works standalone**.

### Later: Add to OpenClaw Multi-Agent Config
```json
{
  "agents": {
    "atlas": {
      "skill": "atlas",
      "telegram_token": "...",
      "personality": "creative-director"
    }
  }
}
```

## Monitoring & Logs

### View Recent Posts
```bash
ls -lah data/posts/
```

### Check Analytics
```bash
# Coming Phase 2: Analytics integration
# For now: Check Postiz dashboard manually
```

### Debug Mode
```bash
DEBUG=true node scripts/atlas-post.js --caption "Test" --images test.png
```

## Troubleshooting

### "Module not found: form-data"
```bash
npm install form-data node-fetch
```

### "Postiz API key required"
```bash
# Check your config.json
cat config/atlas-config.json
# Should have: "apiKey": "sk-..."
```

### "Integration ID not configured"
1. Open Postiz dashboard
2. Go to Integrations
3. For each platform: copy ID
4. Paste into config.json

### "Image not found"
```bash
# Provide full path
node scripts/atlas-post.js \
  --images /full/path/to/image.png
```

## Next Steps

1. **✅ Deploy Atlas** (what you just did)
2. **Create content** (images + captions)
3. **Post regularly** (set up cron/scheduler)
4. **Monitor performance** (check Postiz dashboard)
5. **Later: Combine with other agents** (Morgan, Astra, Sentinel, Quinn)

## Support

- **Questions?** Check SKILL.md
- **API issues?** See Postiz docs: https://postiz.com/docs
- **Bugs?** Create an issue on GitHub

---

**Ready?** Start posting! 🚀

```bash
node scripts/atlas-post.js \
  --config config/atlas-config.json \
  --caption "My first post with Atlas!" \
  --images image.png \
  --platforms tiktok,instagram,twitter,facebook,youtube
```
