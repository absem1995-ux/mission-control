#!/usr/bin/env node
/**
 * Postiz Adapter — Unified API for posting to multiple platforms
 * 
 * This is the backbone of Atlas. It handles:
 * - Multi-platform posting via Postiz
 * - File uploads for images/video
 * - Platform-specific settings
 * - Rate limiting and error handling
 * 
 * Usage:
 *   const adapter = new PostizAdapter(config);
 *   await adapter.post({
 *     platforms: ['tiktok', 'instagram', 'twitter'],
 *     content: 'Your caption',
 *     images: ['slide1.png', 'slide2.png'],
 *     settings: { ... }
 *   });
 */

const fs = require('fs');
const path = require('path');
const { FormData, File } = require('form-data');

class PostizAdapter {
  constructor(config) {
    this.config = config;
    this.baseUrl = 'https://api.postiz.com/public/v1';
    this.apiKey = config.postiz.apiKey;
    
    if (!this.apiKey) {
      throw new Error('Postiz API key required');
    }
  }

  /**
   * Upload a single image file to Postiz
   */
  async uploadImage(filePath) {
    const form = new FormData();
    const fileBuffer = fs.readFileSync(filePath);
    const blob = new File([fileBuffer], path.basename(filePath), { type: 'image/png' });
    form.append('file', blob);

    try {
      const res = await fetch(`${this.baseUrl}/upload`, {
        method: 'POST',
        headers: {
          'Authorization': this.apiKey,
          ...form.getHeaders()
        },
        body: form
      });

      const data = await res.json();
      if (data.error) {
        throw new Error(`Upload failed: ${JSON.stringify(data.error)}`);
      }
      return { id: data.id, path: data.path };
    } catch (err) {
      console.error(`❌ Upload error for ${filePath}:`, err.message);
      throw err;
    }
  }

  /**
   * Upload multiple images with rate limiting
   */
  async uploadImages(filePaths) {
    const images = [];
    for (let i = 0; i < filePaths.length; i++) {
      const filePath = filePaths[i];
      if (!fs.existsSync(filePath)) {
        throw new Error(`File not found: ${filePath}`);
      }
      console.log(`📤 Uploading image ${i + 1}/${filePaths.length}: ${path.basename(filePath)}`);
      const uploadedImage = await this.uploadImage(filePath);
      images.push(uploadedImage);
      
      // Rate limit between uploads (avoid API throttling)
      if (i < filePaths.length - 1) {
        await this._delay(1500);
      }
    }
    return images;
  }

  /**
   * Post to TikTok (slideshow format)
   */
  async postToTikTok({ caption, images, title, privacy = 'SELF_ONLY' }) {
    console.log('\n🎵 Creating TikTok post...');
    
    const integrationId = this.config.postiz.integrationIds?.tiktok;
    if (!integrationId) {
      throw new Error('TikTok integration ID not configured');
    }

    const postRes = await fetch(`${this.baseUrl}/posts`, {
      method: 'POST',
      headers: {
        'Authorization': this.apiKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        type: 'now',
        date: new Date().toISOString(),
        shortLink: false,
        tags: [],
        posts: [{
          integration: { id: integrationId },
          value: [{ content: caption, image: images }],
          settings: {
            __type: 'tiktok',
            title: title || '',
            privacy_level: privacy,
            duet: false,
            stitch: false,
            comment: true,
            autoAddMusic: 'no',
            brand_content_toggle: false,
            brand_organic_toggle: false,
            video_made_with_ai: true,
            content_posting_method: 'UPLOAD'
          }
        }]
      })
    });

    const data = await postRes.json();
    if (data.error) {
      throw new Error(`TikTok posting failed: ${JSON.stringify(data.error)}`);
    }
    console.log('✅ TikTok post created (draft - user adds music)');
    return { platform: 'tiktok', postId: data.id, status: 'draft' };
  }

  /**
   * Post to Instagram (carousel or single image)
   */
  async postToInstagram({ caption, images, title }) {
    console.log('\n📸 Creating Instagram post...');
    
    const integrationId = this.config.postiz.integrationIds?.instagram;
    if (!integrationId) {
      throw new Error('Instagram integration ID not configured');
    }

    // Use first image only for MVP (Instagram carousel requires special handling)
    const postRes = await fetch(`${this.baseUrl}/posts`, {
      method: 'POST',
      headers: {
        'Authorization': this.apiKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        type: 'now',
        date: new Date().toISOString(),
        shortLink: false,
        tags: [],
        posts: [{
          integration: { id: integrationId },
          value: [{ content: caption, image: [images[0]] }],
          settings: {
            __type: 'instagram'
          }
        }]
      })
    });

    const data = await postRes.json();
    if (data.error) {
      throw new Error(`Instagram posting failed: ${JSON.stringify(data.error)}`);
    }
    console.log('✅ Instagram post scheduled');
    return { platform: 'instagram', postId: data.id, status: 'scheduled' };
  }

  /**
   * Post to Twitter (X)
   */
  async postToTwitter({ caption, images, title }) {
    console.log('\n🐦 Creating Twitter/X post...');
    
    const integrationId = this.config.postiz.integrationIds?.twitter;
    if (!integrationId) {
      throw new Error('Twitter integration ID not configured');
    }

    const postRes = await fetch(`${this.baseUrl}/posts`, {
      method: 'POST',
      headers: {
        'Authorization': this.apiKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        type: 'now',
        date: new Date().toISOString(),
        shortLink: false,
        tags: [],
        posts: [{
          integration: { id: integrationId },
          value: [{ content: caption, image: [images[0]] }],
          settings: {
            __type: 'twitter'
          }
        }]
      })
    });

    const data = await postRes.json();
    if (data.error) {
      throw new Error(`Twitter posting failed: ${JSON.stringify(data.error)}`);
    }
    console.log('✅ Twitter/X post scheduled');
    return { platform: 'twitter', postId: data.id, status: 'scheduled' };
  }

  /**
   * Post to Facebook
   */
  async postToFacebook({ caption, images, title }) {
    console.log('\n👤 Creating Facebook post...');
    
    const integrationId = this.config.postiz.integrationIds?.facebook;
    if (!integrationId) {
      throw new Error('Facebook integration ID not configured');
    }

    const postRes = await fetch(`${this.baseUrl}/posts`, {
      method: 'POST',
      headers: {
        'Authorization': this.apiKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        type: 'now',
        date: new Date().toISOString(),
        shortLink: false,
        tags: [],
        posts: [{
          integration: { id: integrationId },
          value: [{ content: caption, image: [images[0]] }],
          settings: {
            __type: 'facebook'
          }
        }]
      })
    });

    const data = await postRes.json();
    if (data.error) {
      throw new Error(`Facebook posting failed: ${JSON.stringify(data.error)}`);
    }
    console.log('✅ Facebook post scheduled');
    return { platform: 'facebook', postId: data.id, status: 'scheduled' };
  }

  /**
   * Post to YouTube (community tab or scheduled premiere)
   */
  async postToYouTube({ caption, images, title }) {
    console.log('\n🎥 Creating YouTube post...');
    
    const integrationId = this.config.postiz.integrationIds?.youtube;
    if (!integrationId) {
      throw new Error('YouTube integration ID not configured');
    }

    // YouTube community tab posts are text + image
    const postRes = await fetch(`${this.baseUrl}/posts`, {
      method: 'POST',
      headers: {
        'Authorization': this.apiKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        type: 'now',
        date: new Date().toISOString(),
        shortLink: false,
        tags: [],
        posts: [{
          integration: { id: integrationId },
          value: [{ content: caption, image: [images[0]] }],
          settings: {
            __type: 'youtube'
          }
        }]
      })
    });

    const data = await postRes.json();
    if (data.error) {
      throw new Error(`YouTube posting failed: ${JSON.stringify(data.error)}`);
    }
    console.log('✅ YouTube community post scheduled');
    return { platform: 'youtube', postId: data.id, status: 'scheduled' };
  }

  /**
   * Post to multiple platforms simultaneously
   */
  async postToMultiplePlatforms({ platforms, caption, images, title }) {
    console.log(`\n🚀 Posting to ${platforms.length} platforms: ${platforms.join(', ')}`);
    
    const results = [];
    
    for (const platform of platforms) {
      try {
        let result;
        switch (platform.toLowerCase()) {
          case 'tiktok':
            result = await this.postToTikTok({ caption, images, title });
            break;
          case 'instagram':
            result = await this.postToInstagram({ caption, images, title });
            break;
          case 'twitter':
          case 'x':
            result = await this.postToTwitter({ caption, images, title });
            break;
          case 'facebook':
            result = await this.postToFacebook({ caption, images, title });
            break;
          case 'youtube':
            result = await this.postToYouTube({ caption, images, title });
            break;
          default:
            console.warn(`⚠️  Unknown platform: ${platform}`);
            continue;
        }
        results.push(result);
      } catch (err) {
        console.error(`❌ Failed to post to ${platform}:`, err.message);
        results.push({
          platform,
          error: err.message,
          status: 'failed'
        });
      }
      
      // Rate limit between platform posts
      await this._delay(1000);
    }
    
    return results;
  }

  /**
   * Utility: delay for rate limiting
   */
  _delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = PostizAdapter;
