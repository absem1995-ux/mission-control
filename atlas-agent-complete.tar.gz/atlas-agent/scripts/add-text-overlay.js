#!/usr/bin/env node
/**
 * Atlas Text Overlay — Add captions to images using node-canvas
 * 
 * Usage:
 *   node add-text-overlay.js --input slides/ --texts captions.json
 * 
 * captions.json format:
 * [
 *   "Slide 1 caption (use \\n for manual line breaks)",
 *   "Slide 2 caption",
 *   ... 6 total
 * ]
 */

const { createCanvas, loadImage } = require('canvas');
const fs = require('fs');
const path = require('path');

class TextOverlay {
  constructor(inputDir, textsPath) {
    this.inputDir = inputDir;
    this.texts = JSON.parse(fs.readFileSync(textsPath, 'utf-8'));

    if (!Array.isArray(this.texts) || this.texts.length !== 6) {
      throw new Error('captions.json must contain exactly 6 text strings');
    }
  }

  /**
   * Wrap text to fit within maxWidth
   */
  wrapText(ctx, text, maxWidth) {
    // Remove emoji (canvas doesn't render them well)
    const cleanText = text.replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, '').trim();

    // Split on manual line breaks
    const manualLines = cleanText.split('\n');
    const wrappedLines = [];

    for (const line of manualLines) {
      if (ctx.measureText(line.trim()).width <= maxWidth) {
        wrappedLines.push(line.trim());
        continue;
      }

      // Auto-wrap if line is too wide
      const words = line.trim().split(/\s+/);
      let currentLine = '';

      for (const word of words) {
        const testLine = currentLine ? `${currentLine} ${word}` : word;
        if (ctx.measureText(testLine).width <= maxWidth) {
          currentLine = testLine;
        } else {
          if (currentLine) wrappedLines.push(currentLine);
          currentLine = word;
        }
      }
      if (currentLine) wrappedLines.push(currentLine);
    }

    return wrappedLines;
  }

  /**
   * Add text overlay to single image
   */
  async addOverlayToImage(inputPath, outputPath, text) {
    const image = await loadImage(inputPath);
    const canvas = createCanvas(image.width, image.height);
    const ctx = canvas.getContext('2d');

    // Draw background image
    ctx.drawImage(image, 0, 0);

    // Setup text styling
    const fontSize = 72;
    const fontFamily = 'Arial, sans-serif';
    ctx.font = `bold ${fontSize}px ${fontFamily}`;
    ctx.fillStyle = 'white';
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.7)';
    ctx.lineWidth = 6;
    ctx.lineJoin = 'round';

    // Wrap text to fit
    const maxWidth = image.width - 100;
    const lines = this.wrapText(ctx, text, maxWidth);

    // Calculate vertical centering
    const lineHeight = fontSize * 1.3;
    const totalHeight = lines.length * lineHeight;
    let startY = (image.height - totalHeight) / 2;

    // Draw text (with stroke for outline effect)
    for (const line of lines) {
      const metrics = ctx.measureText(line);
      const x = (image.width - metrics.width) / 2;

      ctx.strokeText(line, x, startY);
      ctx.fillText(line, x, startY);
      startY += lineHeight;
    }

    // Save to file
    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(outputPath, buffer);
  }

  /**
   * Add overlays to all 6 slides
   */
  async addOverlaysToAll(outputDir) {
    fs.mkdirSync(outputDir, { recursive: true });

    console.log('\n✍️  Adding text overlays to 6 images\n');

    for (let i = 0; i < 6; i++) {
      const slideNum = i + 1;
      const inputPath = path.join(this.inputDir, `slide${slideNum}.png`);
      const outputPath = path.join(outputDir, `slide${slideNum}.png`);

      if (!fs.existsSync(inputPath)) {
        console.error(`  ❌ Input not found: ${inputPath}`);
        continue;
      }

      try {
        await this.addOverlayToImage(inputPath, outputPath, this.texts[i]);
        console.log(`  ✅ Slide ${slideNum} — "${this.texts[i].substring(0, 40)}..."`);
      } catch (err) {
        console.error(`  ❌ Slide ${slideNum} failed: ${err.message}`);
      }
    }

    console.log(`\n📸 Slides with text overlays saved to ${outputDir}`);
  }
}

/**
 * CLI Entry Point
 */
async function main() {
  const args = process.argv.slice(2);
  const getArg = (name) => {
    const idx = args.indexOf(`--${name}`);
    return idx !== -1 ? args[idx + 1] : null;
  };

  const inputDir = getArg('input');
  const textsPath = getArg('texts');
  const outputDir = getArg('output') || inputDir;

  if (!inputDir || !textsPath) {
    console.error('Usage: node add-text-overlay.js --input slides/ --texts captions.json [--output output/]');
    process.exit(1);
  }

  try {
    const overlay = new TextOverlay(inputDir, textsPath);
    await overlay.addOverlaysToAll(outputDir);
    console.log('\n✨ Done!');
  } catch (err) {
    console.error(`\n❌ Error: ${err.message}`);
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = { TextOverlay };
