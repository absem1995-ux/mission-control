#!/usr/bin/env node
/**
 * Atlas Post Orchestrator — Main entry point for Atlas
 * 
 * Generates content, adapts for platforms, and posts to TikTok, Twitter, Instagram, Facebook, YouTube
 * 
 * Usage:
 *   node atlas-post.js --config config.json --title "My Post" --caption "Caption text" --images slide1.png,slide2.png --platforms tiktok,instagram,twitter
 * 
 *   Or with environment defaults:
 *   node atlas-post.js --caption "Caption" --images slide1.png
 */

const fs = require('fs');
const path = require('path');
const PostizAdapter = require('./postiz-adapter');

class AtlasOrchestrator {
  constructor(configPath) {
    if (!fs.existsSync(configPath)) {
      throw new Error(`Config file not found: ${configPath}`);
    }
    this.config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
    this.adapter = new PostizAdapter(this.config);
    this.logger = new Logger();
  }

  /**
   * Validate config has all required fields
   */
  validateConfig() {
    const required = [
      'postiz.apiKey',
      'postiz.integrationIds'
    ];

    for (const key of required) {
      const [top, sub] = key.split('.');
      if (!this.config[top]?.[sub]) {
        throw new Error(`Missing config: ${key}`);
      }
    }
    
    this.logger.info('✅ Config validated');
  }

  /**
   * Parse command-line arguments
   */
  static parseArgs() {
    const args = process.argv.slice(2);
    const result = {};

    for (let i = 0; i < args.length; i++) {
      if (args[i].startsWith('--')) {
        const key = args[i].substring(2);
        const value = args[i + 1];
        if (value && !value.startsWith('--')) {
          if (key === 'images' || key === 'platforms') {
            result[key] = value.split(',').map(v => v.trim());
          } else {
            result[key] = value;
          }
          i++;
        }
      }
    }
    
    return result;
  }

  /**
   * Main posting workflow
   */
  async post(options) {
    const {
      title = '',
      caption = '',
      images = [],
      platforms = ['tiktok', 'instagram', 'twitter']
    } = options;

    if (!caption) {
      throw new Error('Caption is required');
    }

    if (images.length === 0) {
      throw new Error('At least one image is required');
    }

    // Validate image files exist
    const validImages = [];
    for (const img of images) {
      if (fs.existsSync(img)) {
        validImages.push(img);
      } else {
        this.logger.warn(`⚠️  Image not found: ${img}`);
      }
    }

    if (validImages.length === 0) {
      throw new Error('No valid images found');
    }

    // Step 1: Upload all images
    this.logger.info('\n📤 STEP 1: Uploading images...');
    let uploadedImages;
    try {
      uploadedImages = await this.adapter.uploadImages(validImages);
    } catch (err) {
      this.logger.error(`❌ Upload failed: ${err.message}`);
      throw err;
    }

    // Step 2: Post to platforms
    this.logger.info('\n📱 STEP 2: Posting to platforms...');
    let postResults;
    try {
      postResults = await this.adapter.postToMultiplePlatforms({
        platforms,
        caption,
        images: uploadedImages,
        title
      });
    } catch (err) {
      this.logger.error(`❌ Posting failed: ${err.message}`);
      throw err;
    }

    // Step 3: Report results
    this.logger.info('\n📊 STEP 3: Results');
    this.reportResults(postResults);

    return postResults;
  }

  /**
   * Report posting results
   */
  reportResults(results) {
    console.log('\n' + '='.repeat(50));
    console.log('📋 POSTING SUMMARY');
    console.log('='.repeat(50));

    const successful = results.filter(r => !r.error);
    const failed = results.filter(r => r.error);

    console.log(`\n✅ Successful: ${successful.length}/${results.length}`);
    for (const result of successful) {
      console.log(`   • ${result.platform.toUpperCase()} - ${result.status}`);
    }

    if (failed.length > 0) {
      console.log(`\n❌ Failed: ${failed.length}/${results.length}`);
      for (const result of failed) {
        console.log(`   • ${result.platform.toUpperCase()} - ${result.error}`);
      }
    }

    console.log('\n' + '='.repeat(50));
  }
}

/**
 * Simple logger for consistent output
 */
class Logger {
  info(msg) {
    console.log(`ℹ️  ${msg}`);
  }

  warn(msg) {
    console.warn(`⚠️  ${msg}`);
  }

  error(msg) {
    console.error(`❌ ${msg}`);
  }

  success(msg) {
    console.log(`✅ ${msg}`);
  }
}

/**
 * Main entry point
 */
async function main() {
  try {
    const args = AtlasOrchestrator.parseArgs();
    const configPath = args.config || './config.json';

    if (!args.caption) {
      console.error('❌ Missing required argument: --caption');
      console.error('Usage: node atlas-post.js --config config.json --caption "text" --images file1.png,file2.png [--platforms tiktok,instagram,twitter]');
      process.exit(1);
    }

    const orchestrator = new AtlasOrchestrator(configPath);
    orchestrator.validateConfig();

    await orchestrator.post({
      title: args.title || '',
      caption: args.caption,
      images: args.images || [],
      platforms: args.platforms || ['tiktok', 'instagram', 'twitter']
    });

    console.log('\n✨ Done!');
  } catch (err) {
    console.error(`\n❌ Error: ${err.message}`);
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = { AtlasOrchestrator, Logger };
