#!/usr/bin/env node
/**
 * Atlas Analytics — Collect performance data from all platforms
 * 
 * Pulls data from:
 *   - Postiz API (per-post metrics: views, likes, comments, shares)
 *   - Platform native APIs (followers, reach, impressions)
 * 
 * Usage:
 *   node collect-analytics.js --config config.json [--days 7]
 */

const fs = require('fs');
const path = require('path');

class Analytics {
  constructor(config) {
    this.config = config;
    this.postizApiKey = config.postiz.apiKey;
    this.baseUrl = 'https://api.postiz.com/public/v1';

    if (!this.postizApiKey) {
      throw new Error('Postiz API key required in config');
    }
  }

  /**
   * Fetch posts from Postiz API
   */
  async fetchPostsFromPostiz(days = 7) {
    const endDate = new Date();
    const startDate = new Date(endDate.getTime() - days * 24 * 60 * 60 * 1000);

    console.log(`📊 Fetching posts from last ${days} days (${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()})`);

    try {
      const res = await fetch(
        `${this.baseUrl}/posts?startDate=${startDate.toISOString()}&endDate=${endDate.toISOString()}`,
        {
          headers: { 'Authorization': this.postizApiKey }
        }
      );

      if (!res.ok) {
        throw new Error(`Postiz API error: ${res.statusText}`);
      }

      const data = await res.json();
      return data.data || data;
    } catch (err) {
      console.error(`❌ Failed to fetch posts: ${err.message}`);
      return [];
    }
  }

  /**
   * Parse and aggregate metrics by platform
   */
  aggregateMetrics(posts) {
    const platformMetrics = {
      tiktok: { posts: 0, totalViews: 0, totalLikes: 0, totalComments: 0, avgEngagement: 0 },
      instagram: { posts: 0, totalViews: 0, totalLikes: 0, totalComments: 0, avgEngagement: 0 },
      twitter: { posts: 0, totalViews: 0, totalLikes: 0, totalComments: 0, avgEngagement: 0 },
      facebook: { posts: 0, totalViews: 0, totalLikes: 0, totalComments: 0, avgEngagement: 0 },
      youtube: { posts: 0, totalViews: 0, totalLikes: 0, totalComments: 0, avgEngagement: 0 }
    };

    for (const post of posts) {
      const platform = this._getPlatform(post);
      if (!platform || !platformMetrics[platform]) continue;

      const metrics = platformMetrics[platform];
      metrics.posts += 1;

      // Extract metrics (structure varies by platform/Postiz API)
      const views = post.analytics?.views || post.stats?.impressions || 0;
      const likes = post.analytics?.likes || post.stats?.likes || 0;
      const comments = post.analytics?.comments || post.stats?.comments || 0;

      metrics.totalViews += views;
      metrics.totalLikes += likes;
      metrics.totalComments += comments;
    }

    // Calculate averages and engagement rates
    for (const platform in platformMetrics) {
      const metrics = platformMetrics[platform];
      if (metrics.posts > 0) {
        metrics.avgViews = Math.round(metrics.totalViews / metrics.posts);
        metrics.avgLikes = Math.round(metrics.totalLikes / metrics.posts);
        metrics.avgComments = Math.round(metrics.totalComments / metrics.posts);
        metrics.avgEngagement = metrics.totalViews > 0
          ? ((metrics.totalLikes + metrics.totalComments) / metrics.totalViews * 100).toFixed(2)
          : 0;
      }
    }

    return platformMetrics;
  }

  /**
   * Get platform from post object
   */
  _getPlatform(post) {
    if (post.integration?.providerIdentifier) {
      return post.integration.providerIdentifier.toLowerCase();
    }
    if (post.platform) {
      return post.platform.toLowerCase();
    }
    if (post.source) {
      return post.source.toLowerCase();
    }
    return null;
  }

  /**
   * Generate analytics report
   */
  generateReport(metrics) {
    console.log('\n' + '='.repeat(60));
    console.log('📈 ANALYTICS REPORT');
    console.log('='.repeat(60));

    let totalPosts = 0;
    let totalViews = 0;
    let totalEngagement = 0;

    for (const platform in metrics) {
      const m = metrics[platform];
      if (m.posts === 0) continue;

      totalPosts += m.posts;
      totalViews += m.totalViews;

      console.log(`\n${platform.toUpperCase()}`);
      console.log('  Posts:', m.posts);
      console.log('  Total views:', m.totalViews.toLocaleString());
      console.log('  Total likes:', m.totalLikes.toLocaleString());
      console.log('  Total comments:', m.totalComments.toLocaleString());
      console.log('  Avg views/post:', m.avgViews.toLocaleString());
      console.log('  Engagement rate:', `${m.avgEngagement}%`);
    }

    console.log('\n' + '='.repeat(60));
    console.log('TOTAL');
    console.log('  Posts:', totalPosts);
    console.log('  Total views:', totalViews.toLocaleString());
    console.log('  Avg views/post:', Math.round(totalViews / totalPosts).toLocaleString());
    console.log('='.repeat(60));

    return metrics;
  }

  /**
   * Save analytics to file
   */
  saveAnalytics(metrics, outputPath) {
    const timestamp = new Date().toISOString();
    const report = {
      timestamp,
      generatedAt: new Date().toLocaleString(),
      metrics
    };

    fs.writeFileSync(outputPath, JSON.stringify(report, null, 2));
    console.log(`\n💾 Analytics saved to: ${outputPath}`);
  }

  /**
   * Main analytics workflow
   */
  async collectAndReport(days = 7, outputDir = './data/analytics') {
    // Fetch posts
    const posts = await this.fetchPostsFromPostiz(days);
    console.log(`✅ Fetched ${posts.length} posts`);

    // Aggregate metrics
    const metrics = this.aggregateMetrics(posts);

    // Generate and display report
    this.generateReport(metrics);

    // Save to file
    const timestamp = new Date().toISOString().split('T')[0];
    const outputPath = path.join(outputDir, `analytics-${timestamp}.json`);
    fs.mkdirSync(outputDir, { recursive: true });
    this.saveAnalytics(metrics, outputPath);

    return metrics;
  }
}

/**
 * CLI Entry Point
 */
async function main() {
  const args = process.argv.slice(2);
  const getArg = (name) => {
    const idx = args.indexOf(`--${name}`);
    return idx !== -1 ? args[idx + 1] : null;
  };

  const configPath = getArg('config') || './config/atlas-config.json';
  const days = parseInt(getArg('days') || '7', 10);
  const outputDir = getArg('output') || './data/analytics';

  try {
    if (!fs.existsSync(configPath)) {
      throw new Error(`Config not found: ${configPath}`);
    }

    const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
    const analytics = new Analytics(config);

    await analytics.collectAndReport(days, outputDir);

    console.log('\n✨ Analytics collection complete!');
  } catch (err) {
    console.error(`\n❌ Error: ${err.message}`);
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = { Analytics };
