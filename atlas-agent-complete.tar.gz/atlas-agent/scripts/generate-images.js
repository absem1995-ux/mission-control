#!/usr/bin/env node
/**
 * Atlas Image Generation — 3 Providers
 * 
 * Generate 6 slideshow images using:
 *   - OpenAI (DALL-E 3 / gpt-image-1.5) — RECOMMENDED, most photorealistic
 *   - Stability AI (Stable Diffusion XL)
 *   - Replicate (Flux 1.1 Pro or any model)
 *   - Local (you provide the images)
 * 
 * Usage:
 *   node generate-images.js --config config.json --output slides/ --prompts prompts.json
 * 
 * prompts.json format:
 * {
 *   "base": "Shared context for all images",
 *   "slides": [
 *     "Slide 1 unique prompt additions",
 *     "Slide 2 unique prompt additions",
 *     ... 6 total
 *   ]
 * }
 */

const fs = require('fs');
const path = require('path');

class ImageGenerator {
  constructor(config) {
    this.config = config;
    this.provider = config.imageGen?.provider || 'openai';
    this.model = config.imageGen?.model || 'gpt-image-1.5';
    this.apiKey = config.imageGen?.apiKey;

    if (!this.apiKey && this.provider !== 'local') {
      throw new Error(`No API key for image generation provider: ${this.provider}`);
    }

    // Warn if using wrong OpenAI model
    if (this.provider === 'openai' && this.model && !this.model.includes('1.5')) {
      console.warn(`\n⚠️  WARNING: Using "${this.model}" — produces AI-looking images.`);
      console.warn(`   RECOMMENDED: Use "gpt-image-1.5" for photorealistic results.\n`);
    }
  }

  /**
   * Generate single image via OpenAI (DALL-E 3)
   */
  async generateOpenAI(prompt, outputPath) {
    const res = await fetch('https://api.openai.com/v1/images/generations', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: this.model,
        prompt,
        n: 1,
        size: '1024x1536',
        quality: 'hd'
      })
    });

    const data = await res.json();
    if (data.error) throw new Error(`OpenAI error: ${data.error.message}`);

    fs.writeFileSync(outputPath, Buffer.from(data.data[0].b64_json, 'base64'));
  }

  /**
   * Generate single image via Stability AI
   */
  async generateStability(prompt, outputPath) {
    const engineId = this.model || 'stable-diffusion-xl-1024-v1-0';
    const res = await fetch(`https://api.stability.ai/v1/generation/${engineId}/text-to-image`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        text_prompts: [{ text: prompt, weight: 1 }],
        cfg_scale: 7,
        height: 1536,
        width: 1024,
        steps: 30,
        samples: 1
      })
    });

    const data = await res.json();
    if (data.message) throw new Error(`Stability error: ${data.message}`);

    fs.writeFileSync(outputPath, Buffer.from(data.artifacts[0].base64, 'base64'));
  }

  /**
   * Generate single image via Replicate (Flux, etc.)
   */
  async generateReplicate(prompt, outputPath) {
    const modelName = this.model || 'black-forest-labs/flux-1.1-pro';

    // Create prediction
    const createRes = await fetch('https://api.replicate.com/v1/predictions', {
      method: 'POST',
      headers: {
        'Authorization': `Token ${this.apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        version: modelName,
        input: {
          prompt,
          width: 1024,
          height: 1536,
          num_outputs: 1
        }
      })
    });

    let prediction = await createRes.json();
    if (prediction.error) throw new Error(`Replicate error: ${prediction.error}`);

    // Poll for completion
    while (prediction.status !== 'succeeded' && prediction.status !== 'failed') {
      await new Promise(r => setTimeout(r, 2000));
      const pollRes = await fetch(`https://api.replicate.com/v1/predictions/${prediction.id}`, {
        headers: { 'Authorization': `Token ${this.apiKey}` }
      });
      prediction = await pollRes.json();
    }

    if (prediction.status === 'failed') {
      throw new Error(`Replicate prediction failed: ${prediction.error || 'unknown'}`);
    }

    // Download image
    const imageUrl = Array.isArray(prediction.output) ? prediction.output[0] : prediction.output;
    const imgRes = await fetch(imageUrl);
    const buf = Buffer.from(await imgRes.arrayBuffer());
    fs.writeFileSync(outputPath, buf);
  }

  /**
   * Local provider — copy user-provided images
   */
  async generateLocal(prompt, outputPath, slideNum) {
    const localPath = path.join(path.dirname(outputPath), `local_slide${slideNum}.png`);
    if (!fs.existsSync(localPath)) {
      throw new Error(`Local image not found: ${localPath}`);
    }
    fs.copyFileSync(localPath, outputPath);
  }

  /**
   * Generate with retry + timeout
   */
  async generateWithRetry(prompt, outputPath, slideNum, maxRetries = 2) {
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        const abortController = new AbortController();
        const timeout = setTimeout(() => abortController.abort(), 120000);

        switch (this.provider) {
          case 'openai':
            await this.generateOpenAI(prompt, outputPath);
            break;
          case 'stability':
            await this.generateStability(prompt, outputPath);
            break;
          case 'replicate':
            await this.generateReplicate(prompt, outputPath);
            break;
          case 'local':
            await this.generateLocal(prompt, outputPath, slideNum);
            break;
          default:
            throw new Error(`Unknown provider: ${this.provider}`);
        }

        clearTimeout(timeout);
        return true;
      } catch (err) {
        clearTimeout(timeout);
        if (attempt < maxRetries) {
          console.log(`  ⚠️ Attempt ${attempt + 1} failed: ${err.message}. Retrying...`);
          await new Promise(r => setTimeout(r, 3000 * (attempt + 1)));
        } else {
          throw err;
        }
      }
    }
  }

  /**
   * Generate all 6 slides
   */
  async generateAllSlides(prompts, outputDir) {
    if (!prompts.slides || prompts.slides.length !== 6) {
      throw new Error('prompts must contain exactly 6 slides');
    }

    fs.mkdirSync(outputDir, { recursive: true });

    console.log(`\n🎨 Generating 6 images using ${this.provider}/${this.model}`);
    console.log(`   Provider: ${this.provider}`);
    console.log(`   Model: ${this.model}`);
    console.log(`   Output: ${outputDir}\n`);

    let generated = 0;
    let skipped = 0;

    for (let i = 0; i < 6; i++) {
      const slideNum = i + 1;
      const outputPath = path.join(outputDir, `slide${slideNum}.png`);

      // Skip if already exists
      if (fs.existsSync(outputPath) && fs.statSync(outputPath).size > 10000) {
        console.log(`  ⏭️  Slide ${slideNum} already exists, skipping`);
        skipped++;
        generated++;
        continue;
      }

      const fullPrompt = `${prompts.base}\n\n${prompts.slides[i]}`;

      try {
        console.log(`  🔄 Slide ${slideNum}...`);
        await this.generateWithRetry(fullPrompt, outputPath, slideNum);
        console.log(`  ✅ Slide ${slideNum} generated`);
        generated++;
      } catch (err) {
        console.error(`  ❌ Slide ${slideNum} failed: ${err.message}`);
      }
    }

    console.log(`\n📊 Results: ${generated}/6 generated${skipped > 0 ? `, ${skipped} skipped` : ''}`);

    if (generated < 6) {
      console.error(`\n⚠️ ${6 - generated} slides failed. Re-run to retry.`);
      process.exit(1);
    }

    return { generated, skipped, total: 6 };
  }
}

/**
 * CLI Entry Point
 */
async function main() {
  const args = process.argv.slice(2);
  const getArg = (name) => {
    const idx = args.indexOf(`--${name}`);
    return idx !== -1 ? args[idx + 1] : null;
  };

  const configPath = getArg('config');
  const outputDir = getArg('output');
  const promptsPath = getArg('prompts');

  if (!configPath || !outputDir || !promptsPath) {
    console.error('Usage: node generate-images.js --config config.json --output slides/ --prompts prompts.json');
    process.exit(1);
  }

  try {
    const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
    const prompts = JSON.parse(fs.readFileSync(promptsPath, 'utf-8'));

    const generator = new ImageGenerator(config);
    await generator.generateAllSlides(prompts, outputDir);

    console.log('\n✨ Done! Images ready for posting.');
  } catch (err) {
    console.error(`\n❌ Error: ${err.message}`);
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = { ImageGenerator };
