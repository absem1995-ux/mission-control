---
name: atlas
description: Creative Director Agent. Post engaging content to TikTok, Instagram, Twitter/X, Facebook, and YouTube simultaneously. Use for content distribution, multi-platform posting, content adaptation, creative direction.
triggers: 
  - "post to tiktok"
  - "share on instagram"
  - "tweet this"
  - "post to all platforms"
  - "multi-platform content"
exclusions:
  - Email marketing (use Quinn)
  - Customer support (use Sentinel)
  - Workflow automation (use Astra)
  - Strategic communications (use Morgan)
---

# Atlas — Creative Director & Multi-Platform Content Agent

**Role:** Creative Director & Content Distribution  
**Personality:** Bold visionary, trend-spotter, creative risk-taker  
**Philosophy:** "Content isn't an output; it's a conversation. We're not posting—we're building a movement."

## What Atlas Does

Atlas takes your content ideas and posts them to **5 major platforms simultaneously**:
- 🎵 **TikTok** (6-slide slideshow, user adds music)
- 📸 **Instagram** (single image + caption, carousel in Phase 2)
- 🐦 **Twitter/X** (text + image)
- 👤 **Facebook** (single image + caption)
- 🎥 **YouTube** (community tab post)

## Complete Workflow (3 Steps)

### Step 1: Generate Images (Optional)
```bash
# Choose your image generation provider and add API key to config.json
# Providers: openai (recommended), stability, replicate, or local

node scripts/generate-images.js \
  --config config.json \
  --prompts config/example-prompts.json \
  --output slides/
```

**Supported Providers:**
- 🤖 **OpenAI (DALL-E 3)** — RECOMMENDED, photorealistic ($0.04-0.08/image)
- 🎨 **Stability AI** — Very good quality ($0.02-0.03/image)
- ✨ **Replicate (Flux)** — Excellent ($0.03-0.07/image)
- 📁 **Local** — You provide images (free)

### Step 2: Add Text Overlays (Optional)
```bash
# Add captions/hooks to your images
node scripts/add-text-overlay.js \
  --input slides/ \
  --texts config/example-captions.json \
  --output slides-final/
```

### Step 3: Post to All Platforms
```bash
# Post to TikTok, Instagram, Twitter, Facebook, YouTube simultaneously
node scripts/atlas-post.js \
  --config config.json \
  --caption "Your main hook/caption" \
  --images slides-final/slide1.png,slides-final/slide2.png \
  --platforms tiktok,instagram,twitter,facebook,youtube
```

**Results:**
- ✅ TikTok: Draft created (you add music, then publish)
- ✅ Instagram: Post scheduled
- ✅ Twitter: Post scheduled
- ✅ Facebook: Post scheduled
- ✅ YouTube: Community post scheduled

### Step 4: Monitor Analytics (Optional)
```bash
# Collect and report performance data
node scripts/collect-analytics.js \
  --config config.json \
  --days 7
```

Shows views, likes, comments, engagement rates per platform.

## Setup (5 Minutes)

### 1. Get Postiz API Key
- Go to [postiz.com](https://postiz.com)
- Create account or sign in
- Generate API key
- Save it

### 2. Connect Your Platforms to Postiz
- Link TikTok account
- Link Instagram account
- Link Twitter account
- Link Facebook account
- Link YouTube account
- Note the integration IDs

### 3. Configure Atlas
```bash
cp config/atlas-config.template.json config/atlas-config.json
# Edit config.json, add:
# - Postiz API key
# - Integration IDs for each platform
```

### 4. Test It
```bash
node scripts/atlas-post.js \
  --config config.json \
  --caption "Test post" \
  --images test-image.png
```

## Platform Details

### TikTok
- **Format:** 6-slide slideshow (PNG images)
- **Status:** Draft (you add music manually, then publish)
- **Why draft?** TikTok API doesn't allow automated music addition
- **Upload:** `slide1.png` through `slide6.png`

### Instagram
- **Format:** Single image + caption
- **Status:** Scheduled (posts automatically)
- **Carousel coming:** Phase 2 will support multiple images

### Twitter/X
- **Format:** Text + single image
- **Status:** Scheduled (posts automatically)
- **Length:** 280 characters + image

### Facebook
- **Format:** Single image + caption
- **Status:** Scheduled (posts automatically)
- **Reach:** Your page followers

### YouTube
- **Format:** Community tab post (text + image)
- **Status:** Scheduled (posts to community tab)
- **Note:** Requires YouTube channel community feature enabled

## Advanced: Platform-Specific Settings

Edit `config/atlas-config.json` to customize:

```json
{
  "posting": {
    "defaultPlatforms": ["tiktok", "instagram", "twitter"],
    "schedule": {
      "tiktok": ["07:30", "16:30", "21:00"],
      "instagram": ["08:00", "17:00", "20:00"]
    }
  }
}
```

## Troubleshooting

### "Upload failed"
- Check image files exist
- Verify file paths are correct
- Ensure images are PNG format

### "Integration ID not configured"
- Double-check your Postiz integration IDs in config.json
- Verify platform is connected in Postiz dashboard

### "TikTok post stuck in draft"
- This is normal! TikTok API limitation.
- Log into TikTok, add music, then publish

## Phase 2 Features (Coming Soon)

- 🤖 AI image generation (create slides automatically)
- 🎬 Video generation (for YouTube/TikTok)
- 📊 Analytics aggregation (see performance across all platforms)
- 🎨 Template system (predefined slide designs)
- ⏰ Advanced scheduling (optimal posting times per platform)
- 🔄 Content adaptation (auto-adapt text per platform)

## Files

```
atlas-agent/
├── scripts/
│   ├── atlas-post.js          # Main orchestrator
│   ├── postiz-adapter.js      # Platform posting logic
│   └── ...
├── config/
│   └── atlas-config.template.json
├── SKILL.md                    # This file
├── package.json
└── .env.template
```

## Cost

**Monthly (Baseline):**
- Postiz: $50-99/mo (covers all 5 platforms)
- Image generation: Free (Phase 1)

**Phase 2 Optional:**
- AI image generation: $0.03-0.12 per image
- ElevenLabs voiceover: $10-99/mo
- Video generation: $540+/mo

## Next Steps

1. Copy config template: `cp config/atlas-config.template.json config/atlas-config.json`
2. Add your Postiz API key and integration IDs
3. Test with one image: `node scripts/atlas-post.js --caption "Test" --images test.png`
4. Deploy with real content

---

**Questions?** Check references/ for detailed platform guidelines.

**Phase 2?** See ROADMAP.md for upcoming features.
